<?php

namespace Drupal\header_top_links\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'HeaderTopLinksBlock' block.
 *
 * @Block(
 *  id = "header_top_links_block",
 *  admin_label = @Translation("Header Top Links"),
 * )
 */
class HeaderTopLinksBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {

    $user_picture = '';

    if (\Drupal::currentUser()->isAuthenticated()) {
      $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
      $user_name = $user->getAccountName();

      if ($user->user_picture->target_id) {
        $user_picture = file_create_url($user->user_picture->entity->getFileUri());
      }
      else {
        $field = \Drupal\field\Entity\FieldConfig::loadByName('user', 'user', 'user_picture');
        $default_image = $field->getSetting('default_image');
        if (isset($default_image['uuid'])) {
          $file = \Drupal::service('entity.repository')->loadEntityByUuid('file', $default_image['uuid']);
          $user_picture = file_create_url($file->getFileUri());
        }
      }
    }
    else {
      $user_name = $this->t('Anonymous');
    }

    $build = [
      '#theme' => 'header_top_links',
      '#user_name' => $user_name,
      '#user_picture' => $user_picture,
      '#cache' => [
        'max-age' => 0,
      ]
    ];

    return $build;
  }
}
